package com.example.group_129will_hero;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;


    public class Weapons {
        private final ImageView fx;
        public void add(AnchorPane pane){
            pane.getChildren().add(fx);
        }
        public Weapons(double X, double Y) {
            fx = new ImageView();
            fx.setImage(new Image("WeaponSword.png",true));
            fx.setFitWidth(15);
            fx.setFitHeight(40);
            fx.setLayoutX(X);
            fx.setLayoutY(Y);
        }
        public ImageView getFx(){return  fx;}

    }

