package com.example.group_129will_hero;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.Objects;

public class GameOverController {
    @FXML
    private Button returnbb;
    @FXML
    private Stage stage;
    @FXML
    private AnchorPane rootPane;
    @FXML
    private Button resumeButton;

//    public void logout(ActionEvent event){
//    }
    @FXML
    private Button exit;

    public void resume() throws IOException {


        Parent secondView;
        secondView=(AnchorPane) FXMLLoader.load(Objects.requireNonNull(getClass().getResource("midgame.fxml")));
        Scene newScene = new Scene(secondView);
        Stage curStage = (Stage) rootPane.getScene().getWindow();
        curStage.setScene(newScene);


    }

    public void start() throws Exception {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Logout");
        alert.setHeaderText("You're about to logout!");
        alert.setContentText("Do you want to save before exiting?");

        if (alert.showAndWait().get() == ButtonType.OK){
            System.out.println("You successfully logged out");
            System.exit(0);
        }
    }
    public void returnMenu() throws IOException {
        Parent secondView;
        secondView=(AnchorPane) FXMLLoader.load(Objects.requireNonNull(getClass().getResource("MainPage.fxml")));
        Scene newScene = new Scene(secondView);
        Stage curStage = (Stage) rootPane.getScene().getWindow();
        curStage.setScene(newScene);
    }
}
