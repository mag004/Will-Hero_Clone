package com.example.group_129will_hero;
import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.PauseTransition;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Bounds;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.input.RotateEvent;
import javafx.scene.paint.ImagePattern;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.shape.Polygon;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.io.*;
import java.net.URL;
import java.util.ArrayList;
import java.util.Objects;
import java.util.ResourceBundle;

public class HeroController implements Initializable, Collidable{
    Island islands = new Island();

    Orcs orcs = new Orcs();



    @FXML
    private AnchorPane scene;
    @FXML
    private Button settingsButton;
    @FXML
    private ImageView hero;
    @FXML
    private ImageView pillar;
    @FXML
    private ImageView t1;
    @FXML
    private ImageView t2;
    @FXML
    private ImageView i1;
    @FXML
    private ImageView chest;
    @FXML
    private ImageView chest1;
    @FXML
    private ImageView i2;
    @FXML
    private ImageView i3;
    @FXML
    private ImageView i4;
//    @FXML
//    private ImageView i5;
    @FXML
    private ImageView i6;
    @FXML
    private ImageView i7;
    @FXML
    private ImageView i8;
    @FXML
    private ImageView i9;
    @FXML
    private ImageView i10;
    @FXML
    private ImageView i11;
    @FXML
    private ImageView i12;
    @FXML
    private ImageView i13;
    @FXML
    private ImageView i14;
    @FXML
    private ImageView i15;
    @FXML
    private ImageView i16;
    @FXML
    private ImageView i17;
    @FXML
    private ImageView i18;
    @FXML
    private ImageView i19;
    @FXML
    private ImageView i20;
    @FXML
    private ImageView i21;
    @FXML
    private ImageView i22;
    @FXML
    private ImageView i23;
    @FXML
    private ImageView i26;
    @FXML
    private ImageView i27;
    @FXML
    private ImageView i24;
    @FXML
    private ImageView i25;
    @FXML
    private ImageView i29;
    @FXML
    private ImageView i28;
    @FXML
    private ImageView orc;
    @FXML
    private ImageView orc1;
    @FXML
    private ImageView orc2;
    @FXML
    private ImageView orc3;
//    @FXML
//    private ImageView orc4;
    @FXML
    private ImageView orc5;
    @FXML
    private ImageView orc6;
    @FXML
    private ImageView orc7;
    @FXML
    private ImageView orc8;
    @FXML
    private ImageView orc9;
    @FXML
    private ImageView orc10;
    @FXML
    private ImageView orc11;
    @FXML
    private ImageView orc12;
    @FXML
    private ImageView monster1;
    @FXML
    private ImageView monster2;
    @FXML
    private ImageView monster3;
    @FXML
    private ImageView monster4;
    @FXML
    private ImageView boss;
    @FXML
    private Rectangle platform1;
    @FXML
    private Rectangle platform2;
    @FXML
    private Rectangle platform3;
    @FXML
    private Rectangle platform4;
    @FXML
    private Text text;
    @FXML
    private ImageView setbutton;
//    @FXML
//    private ImageView coinimg;
    @FXML
    private Text cointext;
    @FXML
    private Button pauseButton;



    ArrayList<Coin> coins = new ArrayList<>();


    ArrayList<Rectangle> list = new ArrayList<>();

    int fp=0;
    int fp1=1;
    int fp2=2;
    int fp3=3;
    @FXML
    private void settingButtonClick (ActionEvent event) throws IOException {
        Parent secondView;
        secondView=(AnchorPane) FXMLLoader.load(Objects.requireNonNull(getClass().getResource("GameSettings.fxml")));
        Scene newScene = new Scene(secondView);
        Stage curStage = (Stage) scene.getScene().getWindow();
        curStage.setScene(newScene);
    }
    public static saveGame sg = new saveGame();
    public void pause (ActionEvent event) throws IOException {
        paused = true;
        sg.paused = true;
//        HeroController hc = new HeroController();
        sg.heroX = hero.getLayoutX();
        System.out.println(hero.getLayoutX());
        sg.sceneX = scene.getLayoutX();
        sg.heroY = hero.getY();
        sg.coinScore = coin_count;
        sg.score = score;

        try {
            FileOutputStream fileOut = new FileOutputStream("Temp.ser");
            ObjectOutputStream out = new ObjectOutputStream(fileOut);
            out.writeObject(sg);

            out.close();
            fileOut.close();
            System.out.println("Object saved!");
        } catch (IOException i) {
            i.printStackTrace();
        }

        Parent secondView;
        secondView=(AnchorPane) FXMLLoader.load(Objects.requireNonNull(getClass().getResource("GameOver.fxml")));
        Scene newScene = new Scene(secondView);
        Stage curStage = (Stage) scene.getScene().getWindow();
        curStage.setScene(newScene);

    }


        //1 Frame evey 10 millis, which means 100 FP
        Timeline timeline = new Timeline(new KeyFrame(Duration.millis(40), new EventHandler<ActionEvent>() {

            double deltaY = -3;
            @Override
            public void handle(ActionEvent actionEvent) {
                if(doesCollide(hero,chest)){

                    chest.setImage(new Image("ChestOpen.png"));
//                    System.out.println(hero.getX());
//                    System.out.println(hero.getY());
                    Weapons weapon = new Weapons(2100,220);
//                    weapon.getFx().setOnRotate();
                    weapon.add(scene);
                }
                if(doesCollide(hero,chest1)){
                    chest1.setImage(new Image("ChestOpen.png"));
                    Weapons weapon1 = new Weapons(3425,218);
                    weapon1.add(scene);
                }
                if (score == 115){

                    try {
                        Parent secondView;
                        secondView=(AnchorPane) FXMLLoader.load(Objects.requireNonNull(getClass().getResource("WinGame.fxml")));

                    Scene newScene = new Scene(secondView);
                    Stage curStage = (Stage) scene.getScene().getWindow();
                    curStage.setScene(newScene);
                    } catch (Exception e) {
                        System.out.println("gg");
//                        e.printStackTrace();
                    }
                }
                if (hero.getY()==120){
                    Parent secondView;
                    try {
                        secondView=(AnchorPane) FXMLLoader.load(Objects.requireNonNull(getClass().getResource("GameOver.fxml")));

                        Scene newScene = new Scene(secondView);
                        Stage curStage = (Stage) scene.getScene().getWindow();
                        curStage.setScene(newScene);
                        System.out.println("Game Over");
                    } catch (Exception e) {
//                        e.printStackTrace();
                    }

                }
                double y = hero.getY();
//                System.out.println(hero.getBoundsInLocal());
//                System.out.println(i1.getBoundsInLocal());

                if (falling){
                    try{
                        list.get(fp).setY(list.get(fp).getY()+2);

                    }
                    catch (ArrayIndexOutOfBoundsException ae){
                        System.out.println("ae");
                    }

                }
                if (falling1){
                    try{
                        list.get(fp1).setY(list.get(fp1).getY()+2);

                    }
                    catch (ArrayIndexOutOfBoundsException ae){
                        System.out.println("ae");
                    }

                }
                if (falling2){
                    try{
                        list.get(fp2).setY(list.get(fp2).getY()+2);

                    }
                    catch (ArrayIndexOutOfBoundsException ae){
                        System.out.println("ae");
                    }

                }
                if (falling3){
                    try{
                        list.get(fp3).setY(list.get(fp3).getY()+2);

                    }
                    catch (ArrayIndexOutOfBoundsException ae){
                        System.out.println("ae");
                    }

                }

                hero.setX(hero.getX());
                hero.setY(hero.getY() + deltaY);
//            hero.setLayoutY(hero.getLayoutY() - deltaY);


//                Bounds bounds = scene.getBoundsInLocal();
//                boolean rightBorder = hero.getLayoutX() >= (bounds.getMaxX() - hero.getRadius());
//                boolean leftBorder = hero.getLayoutX() <= (bounds.getMinX() + hero.getRadius());
                boolean bottomBorder = hero.getY() >= (y+100);
                boolean topBorder = hero.getY() <= (y);
                double heroY = hero.getY();

                for (int i=0;i<27;i++){
                    if (doesCollide(hero, islands.getImgvw().get(i))){
                        if (hero.getY() == -36 || hero.getY()==0) {
                            deltaY *= -1;
                            break;
                        }
                    }
                    else{
                        if (hero.getY() == -36) {
                            deltaY *= -1;

                        }
                    }

                }
                for (Coin coin : coins) {
                    if (doesCollide(hero, coin.getFx())) {
                        scene.getChildren().remove(coin.getFx());
//                        coins.remove(coin);
                        if(!coin.isCollide()){
                        coin_count+=1;coin.setCollide(true);
                        }
                        cointext.setText(String.valueOf(coin_count));

                    }
                }
//                orcs collision with hero

//                for (int i=0;i<18;i++){

                    if (doesCollide(hero, orc)){
                        orc.setLayoutX(orc.getLayoutX()+50);
                    }
                if (doesCollide(hero, orc1)){
                    orc1.setLayoutX(orc1.getLayoutX()+50);
                }
                if (doesCollide(hero, orc2)){
                    orc2.setLayoutX(orc2.getLayoutX()+50);
                }
                if (doesCollide(hero, orc3)){
                    orc3.setLayoutX(orc3.getLayoutX()+50);
                }
//                if (doesCollide(hero, orc4)){
//                    orc4.setLayoutX(orc4.getLayoutX()+50);
//                }
                if (doesCollide(hero, orc5)){
                    orc5.setLayoutX(orc5.getLayoutX()+50);
                }
                if (doesCollide(hero, orc6)){
                    orc6.setLayoutX(orc6.getLayoutX()+50);
                }
                if (doesCollide(hero, orc7)){
                    orc7.setLayoutX(orc7.getLayoutX()+50);
                }if (doesCollide(hero, orc8)){
                    orc8.setLayoutX(orc8.getLayoutX()+50);
                }if (doesCollide(hero, orc9)){
                    orc9.setLayoutX(orc9.getLayoutX()+50);
                }if (doesCollide(hero, orc10)){
                    orc10.setLayoutX(orc10.getLayoutX()+50);
                }if (doesCollide(hero, orc11)){
                    orc11.setLayoutX(orc11.getLayoutX()+50);
                }
                if (doesCollide(hero, orc12)){
                    orc12.setLayoutX(orc12.getLayoutX()+50);
                }
                if (doesCollide(hero, boss)){
//                    startDragX=10;
                    boss.setLayoutX(boss.getLayoutX()+15);
                }
                if (doesCollide(hero, monster2)){
//                    startDragX=10;
                     monster2.setLayoutX(monster2.getLayoutX()+25);
                }
                if (doesCollide(hero, monster3)){
//                    startDragX=10;
                    monster3.setLayoutX(monster3.getLayoutX()+25);
                }
                if (doesCollide(hero, monster4)){
//                    startDragX=10;
                    monster4.setLayoutX(monster4.getLayoutX()+25);
                }



//                }

                if (hero.getBoundsInParent().intersects(list.get(fp).getBoundsInParent())) {
                    if (hero.getY() == -36 || hero.getY() == 0) {
                        deltaY *= -1;
                    }
                    falling = true;
                }
                if (hero.getBoundsInParent().intersects(list.get(fp1).getBoundsInParent())) {
                    if (hero.getY() == -36 || hero.getY() == 0) {
                        deltaY *= -1;
                    }
                    falling1 = true;
                }
                if (hero.getBoundsInParent().intersects(list.get(fp2).getBoundsInParent())) {
                    if (hero.getY() == -36 || hero.getY() == 0) {
                        deltaY *= -1;
                    }
                    falling2 = true;
                }
                if (hero.getBoundsInParent().intersects(list.get(fp3).getBoundsInParent())) {
                    if (hero.getY() == -36 || hero.getY() == 0) {
                        deltaY *= -1;
                    }
                    falling3 = true;
                }
//                else{
//                    if (hero.getY() == -36) {
//                        deltaY *= -1;
//
//                    }
//                }


//                double Y = monster.getY();
//
//                monster.setX(monster.getX());
//                monster.setY(monster.getY() + monsterY);
////            hero.setLayoutY(hero.getLayoutY() - deltaY);
//
//                if (monster.getY() == -16 || monster.getY() == 0) {
//                    monsterY *= -1;
//                }


            }
        }));

        Timeline timeline1 = new Timeline(new KeyFrame(Duration.millis(40), new EventHandler<ActionEvent>() {
            double deltaOrcY = -2;
            double deltaOrc1Y = -2;
            double deltaOrc2Y = -2;
            double deltaOrc3Y = -2;
//            double deltaOrc4Y = -2;
            double deltaOrc5Y = -2;
            double deltaOrc6Y = -2;
            double deltaOrc7Y = -2;
            double deltaOrc8Y = -2;
            double deltaOrc9Y = -2;
            double deltaOrc10Y = -2;
            double deltaOrc11Y = -2;
            double deltaOrc12Y = -2;
            double deltaBossY =-2;
            double deltaMonster2Y =-2;
            double deltaMonster3Y =-2;
            double deltaMonster4Y =-2;

            @Override
            public void handle(ActionEvent actionEvent) {
                orc.setY(orc.getY() + deltaOrcY);
                orc1.setY(orc1.getY() + deltaOrc1Y);
                orc2.setY(orc2.getY() + deltaOrc2Y);
                orc3.setY(orc3.getY() + deltaOrc3Y);
//                orc4.setY(orc4.getY() + deltaOrc4Y);
                orc5.setY(orc5.getY() + deltaOrc5Y);
                orc6.setY(orc6.getY() + deltaOrc6Y);
                orc7.setY(orc7.getY() + deltaOrc7Y);
                orc8.setY(orc8.getY() + deltaOrc8Y);
                orc9.setY(orc9.getY() + deltaOrc9Y);
                orc10.setY(orc10.getY() + deltaOrc10Y);
                orc11.setY(orc11.getY() + deltaOrc11Y);
                orc12.setY(orc12.getY() + deltaOrc12Y);
                boss.setY(boss.getY() + deltaBossY);
                monster2.setY(monster2.getY() + deltaMonster2Y);
                monster3.setY(monster3.getY() + deltaMonster3Y);
                monster4.setY(monster4.getY() + deltaMonster4Y);

//                orc.setY(orc.getY() + deltaOrcY);
//                for(int j=0;j<13;j++){
//                    orcs.getImgvw().get(j).setX(orcs.getImgvw().get(j).getX());
//                    orcs.getImgvw().get(j).setY(orcs.getImgvw().get(j).getY() + deltaOrcY);
//
//                }


//                orc.setX(orc.getX());
//                orc.setY(orc.getY() + deltaOrcY);
////            hero.setLayoutY(hero.getLayoutY() - deltaY);
//
//                if (orc.getY() == -36 || orc.getY() == 0) {
//                    deltaOrcY *= -1;
//                }
//                orc1.setX(orc1.getX());
//                orc1.setY(orc1.getY() + deltaOrcY);
////            hero.setLayoutY(hero.getLayoutY() - deltaY);
//
//                if (orc1.getY() == -32 || orc1.getY() == 0) {
//                    deltaOrcY *= -1;
//                }
//
//                orc2.setX(orc2.getX());
//                orc2.setY(orc2.getY() + deltaOrcY);
////            hero.setLayoutY(hero.getLayoutY() - deltaY);
//
//                if (orc2.getY() == -32 || orc2.getY() == 0) {
//                    deltaOrcY *= -1;
//                }
//
//                for (int k=0;k<18;k++){
                    for(int m=0;m<27;m++){
//                        System.out.println("colliding");
                        if (doesCollide(orc, islands.getImgvw().get(m))){
//                            System.out.println("pakka colliding");
                            deltaOrcY*=-1;
                            break;
                        }
                        else{
                            if (orc.getY() == -36) {
                                deltaOrcY *= -1;

                            }
                        }
                    }
                for(int m=0;m<27;m++){
//                    System.out.println("colliding");
                    if (doesCollide(orc1, islands.getImgvw().get(m))){
//                        System.out.println("pakka colliding");
                        deltaOrc1Y*=-1;
                        break;
                    }
                    else{
                        if (orc1.getY() == -36) {
                            deltaOrc1Y *= -1;

                        }
                    }
                }
                for(int m=0;m<27;m++){
//                    System.out.println("colliding");
                    if (doesCollide(orc2, islands.getImgvw().get(m))){
//                        System.out.println("pakka colliding");
                        deltaOrc2Y*=-1;
                        break;
                    }
                    else{
                        if (orc2.getY() == -36) {
                            deltaOrc2Y *= -1;

                        }
                    }
                }
                for(int m=0;m<27;m++){
//                    System.out.println("colliding");
                    if (doesCollide(orc3, islands.getImgvw().get(m))){
//                        System.out.println("pakka colliding");
                        deltaOrc3Y*=-1;
                        break;
                    }
                    else{
                        if (orc3.getY() == -36) {
                            deltaOrc3Y *= -1;

                        }
                    }
                }
//                for(int m=0;m<25;m++){
//                    System.out.println("colliding");
//                    if (doesCollide(orc4, islands.getImgvw().get(m))){
//                        System.out.println("pakka colliding");
//                        deltaOrc4Y*=-1;
//                        break;
//                    }
//                    else{
//                        if (orc4.getY() == -36) {
//                            deltaOrc4Y *= -1;
//
//                        }
//                    }
//                }
                for(int m=0;m<27;m++){
//                    System.out.println("colliding");
                    if (doesCollide(orc5, islands.getImgvw().get(m))){
//                        System.out.println("pakka colliding");
                        deltaOrc5Y*=-1;
                        break;
                    }
                    else{
                        if (orc5.getY() == -36) {
                            deltaOrc5Y *= -1;

                        }
                    }
                }
                for(int m=0;m<27;m++){
//                    System.out.println("colliding");
                    if (doesCollide(orc6, islands.getImgvw().get(m))){
//                        System.out.println("pakka colliding");
                        deltaOrc6Y*=-1;
                        break;
                    }
                    else{
                        if (orc6.getY() == -36) {
                            deltaOrc6Y *= -1;

                        }
                    }
                }
                for(int m=0;m<27;m++){
//                    System.out.println("colliding");
                    if (doesCollide(orc7, islands.getImgvw().get(m))){
//                        System.out.println("pakka colliding");
                        deltaOrc7Y*=-1;
                        break;
                    }
                    else{
                        if (orc7.getY() == -36) {
                            deltaOrc7Y *= -1;

                        }
                    }
                }
                for(int m=0;m<27;m++){
//                    System.out.println("colliding");
                    if (doesCollide(orc8, islands.getImgvw().get(m))){
//                        System.out.println("pakka colliding");
                        deltaOrc8Y*=-1;
                        break;
                    }
                    else{
                        if (orc8.getY() == -36) {
                            deltaOrc8Y *= -1;

                        }
                    }
                }
                for(int m=0;m<27;m++){
//                    System.out.println("colliding");
                    if (doesCollide(orc9, islands.getImgvw().get(m))){
//                        System.out.println("pakka colliding");
                        deltaOrc9Y*=-1;
                        break;
                    }
                    else{
                        if (orc9.getY() == -36) {
                            deltaOrc9Y *= -1;

                        }
                    }
                }
                for(int m=0;m<27;m++){
//                    System.out.println("colliding");
                    if (doesCollide(orc10, islands.getImgvw().get(m))){
//                        System.out.println("pakka colliding");
                        deltaOrc10Y*=-1;
                        break;
                    }
                    else{
                        if (orc10.getY() == -36) {
                            deltaOrc10Y *= -1;

                        }
                    }
                }
                for(int m=0;m<27;m++){
//                    System.out.println("colliding");
                    if (doesCollide(orc11, islands.getImgvw().get(m))){
//                        System.out.println("pakka colliding");
                        deltaOrc11Y*=-1;
                        break;
                    }
                    else{
                        if (orc11.getY() == -36) {
                            deltaOrc11Y *= -1;

                        }
                    }
                }
                for(int m=0;m<27;m++){
//                    System.out.println("colliding");
                    if (doesCollide(orc12, islands.getImgvw().get(m))){
//                        System.out.println("pakka colliding");
                        deltaOrc12Y*=-1;
                        break;
                    }
                    else{
                        if (orc12.getY() == -36) {
                            deltaOrc12Y *= -1;

                        }
                    }
                }
                for(int m=0;m<27;m++){
//                    System.out.println("colliding");
                    if (doesCollide(boss, islands.getImgvw().get(m))){
                        deltaBossY*=-1;
                        break;
                    }
                    else{
                        if (boss.getY() == -30) {
                            deltaBossY *= -1;

                        }
                    }
                }
                for(int m=0;m<27;m++){
//                    System.out.println("colliding");
                    if (doesCollide(monster2, islands.getImgvw().get(m))){
                        deltaMonster2Y*=-1;
                        break;
                    }
                    else{
                        if (monster2.getY() == -30) {
                            deltaMonster2Y *= -1;

                        }
                    }
                }
                for(int m=0;m<27;m++){
//                    System.out.println("colliding");
                    if (doesCollide(monster3, islands.getImgvw().get(m))){
                        deltaMonster3Y*=-1;
                        break;
                    }
                    else{
                        if (monster3.getY() == -30) {
                            deltaMonster3Y *= -1;

                        }
                    }
                }
                for(int m=0;m<27;m++){
//                    System.out.println("colliding");
                    if (doesCollide(monster4, islands.getImgvw().get(m))){
                        deltaMonster4Y*=-1;
                        break;
                    }
                    else{
                        if (monster4.getY() == -30) {
                            deltaMonster4Y *= -1;

                        }
                    }
                }


//                }

//                for (int i=0;i<18;i++){
//
//                    for (int j=0; j<18;j++){
//                        if (j==i){
//                            continue;
//                        }
//                        if (doesCollide(orcs.getImgvw().get(j), orcs.getImgvw().get(i))){
//
//                            orcs.getImgvw().get(i).setTranslateX( boom);
//                            boom += 30;
//
//                            break;
//                        }
//
//                    }
//
//                }
            }
        }));
    Timeline timeline2 = new Timeline(new KeyFrame(Duration.millis(150), new EventHandler<ActionEvent>() {
            double i3y = -1;
            double pillarY = -1;

        @Override
        public void handle(ActionEvent actionEvent) {
            double y1 = i3.getY();

            i3.setX(i3.getX());
            i3.setY(i3.getY() + i3y);
//            hero.setLayoutY(hero.getLayoutY() - deltaY);

            if (i3.getY() == -16 || i3.getY() == 0) {
                i3y *= -1;
            }

            double y2 = pillar.getY();

            pillar.setX(pillar.getX());
            pillar.setY(pillar.getY() + pillarY);
//            hero.setLayoutY(hero.getLayoutY() - deltaY);

            if (pillar.getY() == -16 || pillar.getY() == 0) {
                pillarY *= -1;
            }
        }
    }));
    Timeline timeline3 = new Timeline(new KeyFrame(Duration.millis(150), new EventHandler<ActionEvent>() {
        double i1x = -0.5;
        double t1x = -0.5;
        double t2x = -0.5;

        @Override
        public void handle(ActionEvent actionEvent) {
            double x1 = i1.getX();

            i1.setX(i1.getX() + i1x);
            i1.setY(i1.getY());
//            hero.setLayoutY(hero.getLayoutY() - deltaY);

            if (i1.getX() == -10 || i1.getX() == 0) {
                i1x *= -1;
            }

            double x2 = t1.getX();

            t1.setX(t1.getX()+t1x);
            t1.setY(t1.getY());
//            hero.setLayoutY(hero.getLayoutY() - deltaY);

            if (t1.getX() == -10 || t1.getX() == 0) {
                t1x *= -1;
            }
            double x3 = t2.getX();

            t2.setX(t2.getX()+t2x);
            t2.setY(t2.getY());
//            hero.setLayoutY(hero.getLayoutY() - deltaY);

            if (t2.getX() == -10 || t2.getX() == 0) {
                t2x *= -1;
            }

        }
    }));
    @Override
    public boolean doesCollide(ImageView i1, ImageView i2) {

        if(i1.getBoundsInParent().intersects(i2.getBoundsInParent())) {
            return true;
        }
        else{
            return false;
        }
    }
    private boolean falling = false;
    private boolean falling1 = false;
    private boolean falling2 = false;
    private boolean falling3 = false;
    private double startDragX = 40;
    private double boom = 30;
    private double startDragY;
    int score =0 ;
    int coin_count =0;
    public void moveHero(){
//        scene.setOnMouseClicked(e -> {
//                startDragX = e.getSceneX();
//                startDragY = e.getSceneY();
        hero.setTranslateX(hero.getX() + startDragX);
        
//        hero.setX(hero.getX()+startDragX);
        score+=1;
        text.setText(String.valueOf(score));
        text.setTranslateX(startDragX);
        settingsButton.setTranslateX(startDragX);
        cointext.setTranslateX(startDragX);
        setbutton.setTranslateX(startDragX);
//        PerspectiveCamera camera = new PerspectiveCamera(true);
//        camera.setFarClip(1000);
//        camera.setTranslateX(-15);
//        camera.setTranslateY(-15);
//        camera.setTranslateZ(-150);
//        scene.setCamera(camera);
        scene.setTranslateX(-startDragX);
//        scene.setLayoutX(scene.getLayoutX()-startDragX);
        pauseButton.setTranslateX(startDragX);

//            System.out.println(hero.getX()+ startDragX);
        startDragX+=40;

    }
    public boolean paused = false;
        @Override
        public void initialize(URL url, ResourceBundle resourceBundle) {
//            text.setText("0");
//            cointext.setText("0");

//            if (paused) {

                FileInputStream fileIn;
                try {
                    fileIn = new FileInputStream("/Users/manasagarwal/Downloads/Group_129-Will_Hero/Temp.ser");
                    ObjectInputStream in = new ObjectInputStream(fileIn);
                    HeroController.sg = (saveGame) in.readObject();
                    if (sg.paused){
                        sg.paused = false;
                        scene.setLayoutX(sg.sceneX);
                        hero.setLayoutX(sg.heroX);
                        System.out.println("gg");
                        System.out.println(sg.heroX);
//                hero.setY(sg.heroY);
                        text.setText(String.valueOf(sg.score));
                        cointext.setText(String.valueOf(sg.coinScore));
                    }
                    in.close();
                    fileIn.close();

                } catch (FileNotFoundException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                } catch (IOException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                } catch (ClassNotFoundException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }


            coins.add(new Coin(250, 217));
            coins.add(new Coin(276, 217));
            coins.add(new Coin(303, 217));
            coins.add(new Coin(332, 217));
            coins.add(new Coin(361, 217));
            coins.add(new Coin(397, 34));
            coins.add(new Coin(425, 34));
            coins.add(new Coin(453, 34));
            coins.add(new Coin(478, 34));
            coins.add(new Coin(680, 191));
            coins.add(new Coin(707, 191));
            coins.add(new Coin(735, 191));
            coins.add(new Coin(762, 191));
            coins.add(new Coin(680, 223));
            coins.add(new Coin(707, 223));
            coins.add(new Coin(735, 223));
            coins.add(new Coin(762, 223));
            coins.add(new Coin(1270, 178));
            coins.add(new Coin(1295, 178));
            coins.add(new Coin(1320, 178));
            coins.add(new Coin(1345, 178));
            coins.add(new Coin(1372, 178));
            coins.add(new Coin(1397, 178));
            coins.add(new Coin(1270, 209));
            coins.add(new Coin(1295, 209));
            coins.add(new Coin(1320, 209));
            coins.add(new Coin(1345, 209));
            coins.add(new Coin(1372, 209));
            coins.add(new Coin(1397, 209));
            coins.add(new Coin(1784, 196));
            coins.add(new Coin(1813, 196));
            coins.add(new Coin(1843, 196));
            coins.add(new Coin(1874, 196));
            coins.add(new Coin(1905, 196));
            coins.add(new Coin(1935, 196));
            coins.add(new Coin(1967, 196));
            coins.add(new Coin(2187, 204));
            coins.add(new Coin(2214, 204));
            coins.add(new Coin(2242, 204));
            coins.add(new Coin(2267, 204));
            coins.add(new Coin(2292, 204));
            coins.add(new Coin(2538, 206));
            coins.add(new Coin(2568, 206));
            coins.add(new Coin(2600, 206));
            coins.add(new Coin(2925, 183));
            coins.add(new Coin(2954, 183));
            coins.add(new Coin(2983, 183));
            coins.add(new Coin(2925, 211));
            coins.add(new Coin(2954, 211));
            coins.add(new Coin(2983, 211));
            coins.add(new Coin(3175, 198));
            coins.add(new Coin(3205, 198));
            coins.add(new Coin(3234, 198));

            islands.getImgvw().add(i1);
            islands.getImgvw().add(i2);
//            islands.getImgvw().add(i3);
            islands.getImgvw().add(i4);
//            islands.getImgvw().add(i5);
            islands.getImgvw().add(i6);
            islands.getImgvw().add(i7);
            islands.getImgvw().add(i8);
            islands.getImgvw().add(i9);
            islands.getImgvw().add(i10);
            islands.getImgvw().add(i11);
            islands.getImgvw().add(i12);
            islands.getImgvw().add(i13);
            islands.getImgvw().add(i14);
            islands.getImgvw().add(i15);
            islands.getImgvw().add(i16);
            islands.getImgvw().add(i17);
            islands.getImgvw().add(i18);
            islands.getImgvw().add(i19);
            islands.getImgvw().add(i20);
            islands.getImgvw().add(i21);
            islands.getImgvw().add(i22);
            islands.getImgvw().add(i23);
            islands.getImgvw().add(i24);
            islands.getImgvw().add(i25);
            islands.getImgvw().add(i26);
            islands.getImgvw().add(i27);
            islands.getImgvw().add(i28);
            islands.getImgvw().add(i29);

            orcs.getImgvw().add(orc);
            orcs.getImgvw().add(orc1);
            orcs.getImgvw().add(orc2);
            orcs.getImgvw().add(orc3);
//            orcs.getImgvw().add(orc4);
            orcs.getImgvw().add(orc5);
            orcs.getImgvw().add(orc6);
            orcs.getImgvw().add(orc7);
            orcs.getImgvw().add(orc8);
            orcs.getImgvw().add(orc9);
            orcs.getImgvw().add(orc10);
            orcs.getImgvw().add(orc11);
            orcs.getImgvw().add(orc12);
            orcs.getImgvw().add(monster1);
            orcs.getImgvw().add(monster2);
            orcs.getImgvw().add(monster3);
            orcs.getImgvw().add(monster4);
            orcs.getImgvw().add(monster4);
            orcs.getImgvw().add(boss);
//            coin.add(scene);
            for (Coin coin : coins) {
                coin.add(scene);
            }

            list.add(platform1);
            list.add(platform2);
            list.add(platform3);
            list.add(platform4);

            timeline.setCycleCount(Animation.INDEFINITE);
            timeline1.setCycleCount(Animation.INDEFINITE);
            timeline2.setCycleCount(Animation.INDEFINITE);
            timeline3.setCycleCount(Animation.INDEFINITE);
//        new PauseTransition(Duration.millis(20));
//        hero.setTranslateY(hero.getTranslateY() + 70);
            timeline.play();
            timeline1.play();
            timeline2.play();
            timeline3.play();
        }


}
